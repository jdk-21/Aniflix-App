# aniflix_app
[![Build Status](https://dev.azure.com/aniflix/Aniflix%20App/_apis/build/status/d0mmi.Aniflix-App?branchName=master)](https://dev.azure.com/aniflix/Aniflix%20App/_build/latest?definitionId=1&branchName=master)

App for Aniflix

## Links

- Visit the Aniflix Website: https://www2.aniflix.tv/
- Visit our Blog: https://aniflixapp.wordpress.com/
