import 'package:aniflix_app/components/screens/screen.dart';
import 'package:flutter/material.dart';
import '../slider/SliderElement.dart';
import '../custom/slider/slider_with_headline.dart';
import '../../api/APIManager.dart';
import '../../main.dart';

class Homedata{
  List<SliderElement> continues;
  List<SliderElement> airings;
  List<SliderElement> newshows;
  List<SliderElement> discover;

  Homedata(this.continues,this.airings,this.newshows,this.discover);
}

class Home extends StatefulWidget implements Screen{
  MainWidgetState state;
  Future<Homedata> _homedata;
  Function(Future<Homedata>) _callback;

  Home(this.state);
  Home.withData(this.state,this._homedata,this._callback);

  @override
  getScreenName() {
    return "home_screen";
  }

  @override
  HomeState createState() => HomeState(this.state,this._homedata,this._callback);
}

class HomeState extends State<Home>{

  Future<Homedata> homedata;
  List<SliderElement> continues = [];
  Function(Future<Homedata>) _callback;
  MainWidgetState state;

  HomeState(this.state,this.homedata,this._callback){
    if(this.homedata == null){
      this.homedata = APIManager.getHomeData(state, (continues){setState(() {
        this.continues = continues;
      });});
      this._callback(this.homedata);
    }
  }

  @override
  Widget build(BuildContext ctx) {
    return Container(
      key: Key("home_screen"),
      child: FutureBuilder<Homedata>(
      future: homedata,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return Container(
              color: Theme.of(ctx).backgroundColor,
              child: RefreshIndicator(child: ListView(padding: EdgeInsets.only(top: 10), children: [
                (continues.length < 1) ? ((snapshot.data.continues.length > 0) ? HeadlineSlider("Weitersehen",ctx, snapshot.data.continues):Container()) : HeadlineSlider("Weitersehen",ctx, continues),
                HeadlineSlider("Neue Folgen",ctx, snapshot.data.airings),
                HeadlineSlider("Neu auf Aniflix",ctx, snapshot.data.newshows, aspectRatio: 200/300, size: 0.4,),
                HeadlineSlider("Entdecken",ctx, snapshot.data.discover, aspectRatio: 200/300, size: 0.4,),
              ]),
              onRefresh: () async {
                setState(() {
                  this.homedata = APIManager.getHomeData(state, (continues){setState(() {
                    this.continues = continues;
                  });});
                  this._callback(this.homedata);
                });
              },
              ) );
        } else if (snapshot.hasError) {
          return Text("${snapshot.error}");
        }

        // By default, show a loading spinner.
        return Center(child: CircularProgressIndicator());
      },
    ),);
  }
}
