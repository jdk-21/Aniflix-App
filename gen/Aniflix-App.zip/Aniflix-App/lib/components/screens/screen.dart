import 'package:flutter/material.dart';

abstract class Screen extends Widget{

  getScreenName();

}